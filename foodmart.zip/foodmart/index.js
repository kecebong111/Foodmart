const express = require('express');

const adminRoute = require('./routes/adminRoute');
const foodRoute = require('./routes/foodRoute');
const orderRoute = require('./routes/orderRoute');
const { handle404, handle500 } = require('./middlewares/errorHandle');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/admin', adminRoute);
app.use('/food', foodRoute);
app.use('/order', orderRoute);

app.use(handle404);
app.use(handle500);

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});