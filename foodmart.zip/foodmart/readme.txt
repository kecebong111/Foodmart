foodmart backend
--

1. buat folder foodmart sebagai folder untuk project
2. masuk ke folder maduramart dan jalankan: npm init -y
3. install modul2 yang di butuhkan
    npm install express sequelize mysql2 jsonwebtoken bcryptjs multer
    npm install --save-dev nodemon sequelize-cli

4. tambahkan pada package.json
    "scripts": {
      "start": "nodemon index.js",
    }

5. jalankan: npx sequelize-cli init
  untuk membuat koneksi ke db, model dan migration

6. check akan ada tambahan folder baru: config, migrations, models dan seeders

7. buat database foodmart di phpmyadmin
8. edit file config/config.js pada bagian development, sesuaikan user/pass dan dbname dengan mysql
9. test koneksi ke mysql menggunakan command: npx sequelize-cli db:migrate
  pastikan tidak ada error.

10. buat folder2 tambahan: controllers, routes, middlewares dan uploads
11. buat file index.js dengan kerangka sbb:
--
const express = require('express');

const { handle404, handle500 } = require('./middlewares/errorHandle');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(handle404);
app.use(handle500);

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});

12. buat errorHandle.js di folder middleware, ini untuk menghandle error 404 (not found) dan 500 (server error)
--
// Middleware for 404 error
const handle404 = (req, res, next) => {
  res.status(404).json({
    status: false,
    message: 'Endpoint not found'
  });
};

// Middleware for handling 500 errors
const handle500 = (err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    status: false,
    message: 'Internal server error'
  });
};

module.exports = {
  handle404,
  handle500
};


13. jalankan api dengan ketik "npm start" pada terminal, pastikan foldernya sudah sesuai dak tidak ada error

14. create models dan migration dengan command sbb:
    npx sequelize-cli model:generate --name Admin --attributes name:string,email:string,password:string
    npx sequelize-cli model:generate --name Food --attributes name:string,spicy_level:string,price:double,image:string
    npx sequelize-cli model:generate --name OrderList --attributes customer_name:string,table_number:string,order_date:string
    npx sequelize-cli model:generate --name OrderDetail --attributes orderId:integer,foodId:integer,quantity:integer,price:double

15. edit file model pada folder models untuk mendefinisikan relasi OrderList dan OrderDetail ke table Admin dan Food
tambahkan di atas return;

models/food.js
--
  Food.associate = (models) => {
    Food.belongsToMany(models.OrderList, {
      through: 'OrderDetail',
      foreignKey: 'foodId',
      otherKey: 'orderId',
    });
  };

models/orderlist.js
--
  OrderList.associate = (models) => {
    OrderList.hasMany(models.OrderDetail, {
      as: 'OrderDetails',
      foreignKey: 'orderId',
    });
  };

orderdetail.js
--
  OrderDetail.associate = (models) => {
    OrderDetail.belongsTo(models.OrderList, {
      foreignKey: 'orderId',
    });
    OrderDetail.belongsTo(models.Food, {
      foreignKey: 'foodId',
    });
  };

16. Jalankan command: npx sequelize-cli db:migrate 
    untuk membuat 4 table/model yang kita sebutkan di atas, Admin, Food, OrderList dan OrderDetail

17. buat validate.js dan auth.js sesuai contekan dan taroh di folder middlewares

18. buat controller untuk admin, food, order. contoh yang ada di folder controllers
19. buat route untuk admin, food, dan order. contoh yang ada di folder routes

20. tambahkan route pada folder index.js sehingga hasil akhir dari index.js seperti file di bawah
--
const express = require('express');

const adminRoute = require('./routes/adminRoute');
const foodRoute = require('./routes/foodRoute');
const orderRoute = require('./routes/orderRoute');
const { handle404, handle500 } = require('./middlewares/errorHandle');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/admin', adminRoute);
app.use('/food', foodRoute);
app.use('/order', orderRoute);

app.use(handle404);
app.use(handle500);

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
