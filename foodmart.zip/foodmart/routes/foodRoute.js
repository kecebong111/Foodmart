const express = require('express');
const foodController = require('../controllers/foodController');
const validate = require('../middlewares/validate');
const auth = require('../middlewares/auth');

const router = express.Router();

router.post('/', foodController.upload.single('image'), validate.food, foodController.createFood);
router.get('/:search', foodController.getAllFoods);
router.put('/:id', auth.verifyToken, foodController.upload.single('image'), validate.food, foodController.updateFood);
router.delete('/:id', auth.verifyToken, foodController.deleteFood);

module.exports = router;
