const express = require('express');
const adminController = require('../controllers/adminController');
const validate = require('../middlewares/validate');
const auth = require('../middlewares/auth');

const router = express.Router();

router.post('/', validate.admin, adminController.createAdmin);
router.get('/', auth.verifyToken, adminController.getAllAdmins);
router.get('/:id', auth.verifyToken, adminController.getAdmin);
router.put('/:id', auth.verifyToken, validate.admin, adminController.updateAdmin);
router.delete('/:id', auth.verifyToken, adminController.deleteAdmin);
router.post('/auth', adminController.login);

module.exports = router;
