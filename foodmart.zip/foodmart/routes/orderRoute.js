const express = require('express');
const orderController = require('../controllers/orderController');
const validate = require('../middlewares/validate');
const auth = require('../middlewares/auth');

const router = express.Router();

router.post('/', orderController.createOrder);
router.get('/', auth.verifyToken, orderController.getOrders);

module.exports = router;