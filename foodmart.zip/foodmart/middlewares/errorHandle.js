// Middleware for 404 error
const handle404 = (req, res, next) => {
  res.status(404).json({
    status: false,
    message: 'Endpoint not found'
  });
};

// Middleware for handling 500 errors
const handle500 = (err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    status: false,
    message: 'Internal server error'
  });
};

module.exports = {
  handle404,
  handle500
};