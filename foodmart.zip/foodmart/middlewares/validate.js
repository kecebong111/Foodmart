module.exports = {
  admin(req, res, next) {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ 
        sucess: false,
        message: 'Missing required fields' 
      });
    }
    next();
  },

  food(req, res, next) {
    const { name, spicy_level, price } = req.body;
    if (!name || !spicy_level || price === undefined) {
      return res.status(400).json({ 
        sucess: false,
        message: 'Missing required fields' 
      });
    }
    if (price <= 0) {
      return res.status(400).json({ 
        success: false,
        message: 'Price should be greater than 0' 
      });
    }
    next();
  }
}
