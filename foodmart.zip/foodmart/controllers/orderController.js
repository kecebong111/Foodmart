const { OrderList, OrderDetail, Food, sequelize } = require('../models');

module.exports = {
  async createOrder(req, res) {
    const { customer_name, table_number, order_date, order_detail } = req.body;

    const transaction = await sequelize.transaction();
    try {
      const newOrder = await OrderList.create({
        customer_name,
        table_number,
        order_date
      }, { transaction });

      const details = order_detail.map(detail => ({
        orderId: newOrder.id,
        foodId: detail.food_id,
        quantity: detail.quantity,
        price: detail.price
      }));
      await OrderDetail.bulkCreate(details, { transaction });

      await transaction.commit();
      res.status(201).json({
        status: true,
        data: newOrder,
        message: "Order list has created"
      });
    } catch (error) {
      await transaction.rollback();
      res.status(500).json({
        status: false,
        message: "Order list creation failed",
        error: error.message
      });
    }
  },

  async getOrders(req, res) {
    try {
      const orders = await OrderList.findAll({
        include: [
          {
            model: OrderDetail,
            as: 'OrderDetails',
            include: [Food]
          }
        ]
      });

      res.json({
        status: true,
        data: orders,
        message: 'Order list has retrieved'
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: "Failed to retrieve orders",
        error: error.message
      });
    }
  }
};
