const { Food } = require('../models');
const multer = require('multer');
const path = require('path');
const { Op } = require('sequelize');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

module.exports = {
  upload,

  async createFood(req, res) {
    const { name, spicy_level, price } = req.body;
    const image = req.file ? req.file.filename : null;

    try {
      const food = await Food.create({ name, spicy_level, price, image });
      const output = {
        id: food.id,
        name: food.name,
        spicy_level: food.spicy_level,
        price: food.price,
        image: food.image,
        createdAt: food.createdAt,
        updatedAt: food.updatedAt
      };

      res.status(201).json({
        status: true,
        data: output,
        message: 'Food has created'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async getAllFoods(req, res) {
    try {
      const search = req.params.search;

      const foods = await Food.findAll({
        where: {
          name: {
            [Op.like]: `${search}%`
          }
        }
      });

      res.json({
        status: true,
        data: foods,
        message: 'Food has retrieved'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async updateFood(req, res) {
    const { name, spicy_level, price } = req.body;
    const image = req.file ? req.file.filename : null;

    try {
      const food = await Food.findByPk(req.params.id);
      if (!food) return res.status(404).json({ 
        success: false,
        error: 'Food not found' 
      });

      food.name = name || food.name;
      food.spicy_level = spicy_level || food.spicy_level;
      food.price = price || food.price;
      food.image = image || food.image;

      await food.save();
      res.json({
        status: true,
        data: food,
        message: 'Food has updated'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async deleteFood(req, res) {
    try {
      const food = await Food.findByPk(req.params.id);
      if (!food) return res.status(404).json({ error: 'Food not found' });

      await food.destroy();
      res.json({
        status: true,
        data: food,
        message: 'Food has deleted' 
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  }
};
