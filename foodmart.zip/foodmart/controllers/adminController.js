const { Admin } = require('../models');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

module.exports = {
  async createAdmin(req, res) {
    const { name, email, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const admin = await Admin.create({ name, email, password: hashedPassword });

      const output = {
        id: admin.id,
        name: admin.name,
        email: admin.email,
        createdAt: admin.createdAt,
        updatedAt: admin.updatedAt
      };

      res.status(201).json({
        status: true,
        data: output,
        message: 'Admin has created'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async getAdmin(req, res) {
    try {
      const admin = await Admin.findByPk(req.params.id);
      if (!admin) return res.status(404).json({ 
        status: false,
        message: 'Admin not found' 
      });
      res.json({
        status: true,
        data: admin,
        message: 'Admin has retrieved'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async getAllAdmins(req, res) {
    try {
      const admins = await Admin.findAll();
      res.json({
        status: true,
        data: admins,
        message: 'Admin has retrieved'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async updateAdmin(req, res) {
    const { name, email, password } = req.body;
    try {
      const admin = await Admin.findByPk(req.params.id);
      if (!admin) return res.status(404).json({ 
        status: false,
        message: 'Admin not found' 
      });

      if (password) {
        admin.password = await bcrypt.hash(password, 10);
      }
      admin.name = name || admin.name;
      admin.email = email || admin.email;
      await admin.save();

      res.json({
        status: true,
        data: admin,
        message: 'Admin has updated'
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async deleteAdmin(req, res) {
    try {
      const admin = await Admin.findByPk(req.params.id);
      if (!admin) return res.status(404).json({ 
        status: false,
        message: 'Admin not found' 
      });

      await admin.destroy();
      res.json({
        status: true,
        data: admin,
        message: 'Admin has deleted' 
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  },

  async login(req, res) {
    const { email, password } = req.body;
    try {
      const admin = await Admin.findOne({ where: { email } });
      if (!admin || !(await bcrypt.compare(password, admin.password))) {
        return res.status(401).json({ 
          status: false,
          message: 'Invalid credentials' 
        });
      }
      const token = jwt.sign({ id: admin.id, role: 'admin' }, 'secret_key', {
        expiresIn: '1h'
      });
      res.json({
        suscess: true, 
        logged: true,
        message: "Login Success",
        token 
      });
    } catch (error) {
      res.status(400).json({ 
        status: false,
        message: error.message 
      });
    }
  }
};
